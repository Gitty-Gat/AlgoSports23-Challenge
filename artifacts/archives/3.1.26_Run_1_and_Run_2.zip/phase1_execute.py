from __future__ import annotations

import json
import os
import re
import shutil
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd

from src.nextgen_pipeline import run_nextgen_pipeline


ROOT = Path(__file__).resolve().parent


def _next_model_number(root: Path) -> int:
    nums: List[int] = []
    pat = re.compile(r"^Submission\.zip(\d+)(?:\.zip)?$", re.IGNORECASE)
    for p in root.iterdir():
        m = pat.match(p.name)
        if m:
            try:
                nums.append(int(m.group(1)))
            except Exception:
                pass
    for p in (root / "legacy_reports").glob("final_report_model*.pdf") if (root / "legacy_reports").exists() else []:
        m = re.search(r"model(\d+)", p.name)
        if m:
            nums.append(int(m.group(1)))
    return (max(nums) + 1) if nums else 1


def _archive_previous_reports(root: Path, model_num: int) -> None:
    legacy = root / "legacy_reports"
    legacy.mkdir(exist_ok=True)
    for fname in ["final_report.pdf", "run_report.md"]:
        src = root / fname
        if not src.exists():
            continue
        dst = legacy / f"{src.stem}_model{model_num}{src.suffix}"
        if dst.exists():
            dst.unlink()
        shutil.move(str(src), str(dst))


def _set_env(base: Dict[str, str], extra: Dict[str, str]) -> Dict[str, str]:
    prev = {}
    for k, v in {**base, **extra}.items():
        prev[k] = os.environ.get(k)
        os.environ[k] = str(v)
    return prev


def _restore_env(prev: Dict[str, str]) -> None:
    for k, v in prev.items():
        if v is None:
            os.environ.pop(k, None)
        else:
            os.environ[k] = v


def _gates_pass(metrics: Dict[str, float]) -> bool:
    return (
        float(metrics.get("mean_rmse", float("inf"))) <= 35.2
        and float(metrics.get("corr", float("-inf"))) >= 0.60
        and float(metrics.get("mean_tail_dispersion", float("-inf"))) >= 0.58
        and float(metrics.get("mean_tail_bias", float("-inf"))) >= -6.0
        and float(metrics.get("fold2_rmse", float("inf"))) <= 38.0
    )


def _top3_all_global(root: Path) -> bool:
    p = root / "runner_up_configs.json"
    if not p.exists():
        return True
    obj = json.loads(p.read_text(encoding="utf-8"))
    rows = obj.get("top_candidates", [])
    if len(rows) < 3:
        return True
    mods = [str(r.get("module_name", r.get("module", ""))) for r in rows[:3]]
    return len(set(mods)) == 1 and mods[0] == "expand_affine_global"


def _current_fit_count(root: Path) -> int:
    p = root / "run_metadata.json"
    if not p.exists():
        return 0
    try:
        obj = json.loads(p.read_text(encoding="utf-8"))
        return int(obj.get("model_fit_count", 0))
    except Exception:
        return 0


def _rotate_submission(root: Path, model_num: int) -> None:
    sub = root / "Submission.zip"
    if sub.exists():
        dst = root / f"Submission.zip{model_num}"
        if dst.exists():
            if dst.is_dir():
                shutil.rmtree(dst)
            else:
                dst.unlink()
        shutil.move(str(sub), str(dst))
    new_sub = root / "Submission.zip"
    new_sub.mkdir(exist_ok=True)
    shutil.copy2(root / "Predictions.csv", new_sub / "Predictions.csv")
    shutil.copy2(root / "Rankings.xlsx", new_sub / "Rankings.xlsx")


def _print_evidence(run1: Dict[str, Any], run2: Dict[str, Any], root: Path) -> None:
    run1_metrics = run1.get("phase_metrics", {})
    run2_metrics = run2.get("phase_metrics", {})
    selected_cfg = json.loads((root / "selected_config.json").read_text(encoding="utf-8"))
    fold_df = run2.get("outer_fold_metrics")
    if isinstance(fold_df, pd.DataFrame) and not fold_df.empty:
        fold_text = fold_df[["outer_fold", "rmse", "tail_rmse", "tail_dispersion_ratio", "tail_bias", "corr"]].to_string(index=False)
    else:
        fold_text = "(empty)"

    print("\n=== PHASE 1 EVIDENCE ===")
    print("Run 1 metrics:")
    print(json.dumps(run1_metrics, indent=2, sort_keys=True))
    print("\nRun 2 metrics:")
    print(json.dumps(run2_metrics, indent=2, sort_keys=True))
    print("\nFold-by-fold metrics (Run 2):")
    print(fold_text)
    print("\nSelected model family:")
    print(selected_cfg.get("model_family"))
    print("\nSelected module:")
    print(selected_cfg.get("postprocess", {}).get("module"))
    print("\nSelected features:")
    print(", ".join(selected_cfg.get("features", [])))
    print("\nHyperparameters:")
    print(json.dumps(selected_cfg.get("core_candidate", {}), indent=2, sort_keys=True))
    print("\nPostprocess hyperparameters:")
    print(json.dumps(selected_cfg.get("postprocess", {}), indent=2, sort_keys=True))
    print(f"\nNumber of fits used: {run2.get('model_fit_count')}")
    print("\nRegime gate change confirmation:")
    print(selected_cfg.get("gate_confirmation"))


def main() -> int:
    model_num = _next_model_number(ROOT)
    _archive_previous_reports(ROOT, model_num)

    base_env = {
        "ALGOSPORTS_PIPELINE_ENGINE": "nextgen",
        "ALGOSPORTS_FAST_MODE": "0",
        "ALGOSPORTS_ENABLE_OPTIMIZATIONS": "1",
        "ALGOSPORTS_MAX_MODEL_FITS": "5000",
        "ALGOSPORTS_MAX_FITS": "5000",
        "ALGOSPORTS_MAX_TOTAL_SECONDS": "1800",
        "ALGOSPORTS_MAX_SCAN_SECONDS": "600",
    }
    search_levels = [
        {
            "ALGOSPORTS_SCAN_RETURN_TOP": "8",
            "ALGOSPORTS_SCAN_PRUNE_TOPN": "90",
            "ALGOSPORTS_SCAN_PRUNE_FRAC": "0.60",
            "ALGOSPORTS_HISTGB_BAG_N_MODELS": "2",
        },
        {
            "ALGOSPORTS_SCAN_RETURN_TOP": "12",
            "ALGOSPORTS_SCAN_PRUNE_TOPN": "140",
            "ALGOSPORTS_SCAN_PRUNE_FRAC": "0.75",
            "ALGOSPORTS_HISTGB_BAG_N_MODELS": "3",
            "ALGOSPORTS_MAX_MODEL_FITS": "7000",
            "ALGOSPORTS_MAX_FITS": "7000",
            "ALGOSPORTS_MAX_TOTAL_SECONDS": "2200",
        },
        {
            "ALGOSPORTS_SCAN_RETURN_TOP": "16",
            "ALGOSPORTS_SCAN_PRUNE_TOPN": "220",
            "ALGOSPORTS_SCAN_PRUNE_FRAC": "0.90",
            "ALGOSPORTS_HISTGB_BAG_N_MODELS": "4",
            "ALGOSPORTS_MAX_MODEL_FITS": "9000",
            "ALGOSPORTS_MAX_FITS": "9000",
            "ALGOSPORTS_MAX_TOTAL_SECONDS": "2800",
        },
    ]

    run1_result: Dict[str, Any] | None = None
    run2_result: Dict[str, Any] | None = None
    for i, level_env in enumerate(search_levels, start=1):
        prev = _set_env(base_env, {**level_env, "ALGOSPORTS_PHASE1_RUN": "run1", "ALGOSPORTS_TIMING_TAG": f"phase1_run1_l{i}"})
        try:
            run1_result = run_nextgen_pipeline(ROOT, seed=23)
        finally:
            _restore_env(prev)
        break

    attempts = 0
    for level_env in search_levels:
        attempts += 1
        prev = _set_env(base_env, {**level_env, "ALGOSPORTS_PHASE1_RUN": "run2", "ALGOSPORTS_TIMING_TAG": f"phase1_run2_attempt{attempts}"})
        try:
            run2_result = run_nextgen_pipeline(ROOT, seed=23)
        finally:
            _restore_env(prev)
        metrics = dict(run2_result.get("phase_metrics", {}))
        fit_used = _current_fit_count(ROOT)
        run2_result["model_fit_count"] = fit_used
        fit_ok = int(fit_used) >= 800
        gates_ok = _gates_pass(metrics)
        diversity_ok = not _top3_all_global(ROOT)
        if gates_ok and fit_ok and diversity_ok:
            break

    if run1_result is None or run2_result is None:
        raise RuntimeError("Phase 1 execution failed before producing run outputs.")

    metrics = dict(run2_result.get("phase_metrics", {}))
    fit_used = _current_fit_count(ROOT)
    run2_result["model_fit_count"] = fit_used
    fit_ok = int(fit_used) >= 800
    gates_ok = _gates_pass(metrics)
    diversity_ok = not _top3_all_global(ROOT)
    if not (gates_ok and fit_ok and diversity_ok):
        raise RuntimeError(
            f"Phase 1 gates not satisfied. gates_ok={gates_ok}, fit_ok={fit_ok}, diversity_ok={diversity_ok}, metrics={metrics}"
        )

    _rotate_submission(ROOT, model_num)
    _print_evidence(run1_result, run2_result, ROOT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
