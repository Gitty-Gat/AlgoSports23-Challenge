# Run Report

- Timestamp (UTC): 2026-02-27T01:06:02.572753+00:00
- Git hash: `1aaa14e93a225970a75736c5fd1f73a703e08fc3`
- selected_config.json: `C:\algosports23\AlgoSports23-Challenge\selected_config.json`
- selected_config digest (sha256): `1b131fd3bfbfca10357cdb4548c12fecd516b1b68c2e7ee4b6d53796fa61c214`
- oof_predictions.csv: `C:\algosports23\AlgoSports23-Challenge\oof_predictions.csv`
- oof_predictions.parquet: `C:\algosports23\AlgoSports23-Challenge\oof_predictions.parquet`

## Selection Lock Proof
- Rating-stage selected config id: `massey_alpha=10.0|use_elo=1|elo_home_adv=60.0|elo_k=24.0|elo_decay_a=0.0|elo_decay_g=100.0`
- Rating-stage tail lambda: `0.1`
- Rating-stage xtail lambda: `0.05`
- Rating-stage stability lambda: `0.1`
- Rating-stage dispersion lambda: `0.05`
- Rating-stage tail-dispersion lambda: `0.05`
- Model-stage selected config id: `massey_alpha=10.0|use_elo=1|elo_home_adv=60.0|elo_k=24.0|elo_decay_a=0.0|elo_decay_g=100.0||elasticnet|alpha=1.0|l1_ratio=0.05||module=expand_affine_global`
- Model-stage tail lambda: `0.1`
- Model-stage xtail lambda: `0.05`
- Model-stage stability lambda: `0.1`
- Model-stage dispersion lambda: `0.05`
- Model-stage tail-dispersion lambda: `0.05`
- Selection gate rejections count: `43`
- Massey-only gate applied: `False`
- Full-train stage performed refit-only on locked selected configuration.

## Outer Fold Table (Selected Config)

```text
 fold      rmse       mae  tail_rmse  dispersion_ratio  max_abs_pred
    1 40.393625 31.474310  67.065596          0.464338     84.011136
    2 39.641191 30.826189  62.392968          0.660925     77.100694
    3 34.506880 28.277725  47.736634          0.764153     75.996116
    4 30.955140 24.542059  46.294981          0.787362     84.748944
    5 37.417390 30.556882  57.872225          0.690391     93.497205
```

## Summary Stats
- mean_rmse: 36.582845
- std_rmse: 3.480020
- max_fold_rmse: 40.393625
- mean_disp_ratio: 0.673434
- mean_tailrmse: 56.272481

## Diagnostics
- Mean MAE: 29.135433
- Mean Extreme Tail RMSE: 63.848533
- Mean tail dispersion ratio: 0.463505
- Mean bias: -0.993026
- Mean tail bias: -9.771919
- Selected expansion affine r_base: 0.43764575031495956
- Selected expansion affine naive_r: 2.284953068275728
- Selected expansion affine s_star: 1.1398312338860612
- Selected expansion affine chosen_s: 1.6
- Selected expansion affine eta: 0.9
- Selected piecewise t: None
- Selected piecewise k: None
- Selected piecewise q: None
- Gate rejected configs: 43 / 65
- Gate reason `invalid_postprocess`: 39
- Gate reason `piecewise_eligibility_gate`: 4

## Validation Proofs
- predictions.csv exists: True
- predictions rows: 75
- predictions Team1_WinMargin int: True
- predictions Team1_WinMargin missing: 0
- rankings.xlsx exists: True
- rankings rows: 165
- rank permutation 1..165: True
- final_report.pdf exists: True
- final_report.pdf size_bytes: 120753
- oof_predictions.csv exists: True
- oof_predictions.parquet exists: True
- oof_predictions required cols: True